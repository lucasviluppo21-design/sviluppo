import { Component, OnInit, OnDestroy } from '@angular/core';
import { FirebaseService } from '../../services/firebase.service'; // Importazione corretta del servizio
import { Observable } from 'rxjs'; // Necessario per lavorare con i dati asincroni

// Definizione dell'interfaccia utente (come l'hai fornita)
interface User {
  id: string;
  name: string;
  signupDate: string;
  email: string;
  status: 'Attivo' | 'Inattivo';
  avatarUrl?: string;
}

@Component({
  selector: 'app-anagrafica',
  templateUrl: './anagrafica.component.html',
  styleUrls: ['./anagrafica.component.css'],
  standalone: false
})
export class AnagraficaComponent implements OnInit, OnDestroy {
  // --- Proprietà per Ricerca e Filtri ---
  searchTerm: string = '';
  showFilters: boolean = false;
  filterStatus: string = '';
  filterHasEmail: string = '';

  // --- Dati Utenti (Inizializzati a vuoto, pronti per Firebase) ---
  users: User[] = []; // Array vuoto per i dati
  filteredUsers: User[] = [];

  // --- Proprietà Modale ---
  modalOpen: boolean = false;
  form = {
    avatar: '',
    nome: '',
    cognome: '',
    emailModal: '',
    phone: '',
    signupDateModal: '',
    isActive: true
  };
  avatarLoading: boolean = false;

  // 1. CORREZIONE DELL'ERRORE DI INIEZIONE (NullInjectorError)
  constructor(private firebaseService: FirebaseService) { }

  ngOnInit() {
    // 3. INTEGR. INIZIALE DI FIREBASE: Al caricamento, carica gli utenti
    // Qui andrebbe la logica per caricare gli utenti da Firestore
    // Esempio: this.firebaseService.getUsers().subscribe(data => { this.users = data; this.applyFilters(); });
    
    // Per ora, applica i filtri sull'array vuoto
    this.applyFilters();
  }

  ngOnDestroy() { }

  // --- Metodi per la gestione della Modale (Nessuna modifica necessaria) ---
  openModal() {
    this.modalOpen = true;
    this.form = {
      avatar: '',
      nome: '',
      cognome: '',
      emailModal: '',
      phone: '',
      signupDateModal: '',
      isActive: true
    };
  }

  closeModal() {
    this.modalOpen = false;
  }

  // --- Metodi per Ricerca e Filtri (Nessuna modifica necessaria) ---
  onSearchChange() {
    this.applyFilters();
  }

  toggleFilters() {
    this.showFilters = !this.showFilters;
  }

  applyFilters() {
    let tempUsers = [...this.users];

    if (this.searchTerm) {
      const lowerCaseSearchTerm = this.searchTerm.toLowerCase();
      tempUsers = tempUsers.filter(user =>
        user.name.toLowerCase().includes(lowerCaseSearchTerm) ||
        user.email.toLowerCase().includes(lowerCaseSearchTerm)
      );
    }

    if (this.filterStatus) {
      tempUsers = tempUsers.filter(user => user.status === this.filterStatus);
    }

    if (this.filterHasEmail === 'with') {
      tempUsers = tempUsers.filter(user => user.email && user.email !== '');
    } else if (this.filterHasEmail === 'without') {
      tempUsers = tempUsers.filter(user => !user.email || user.email === '');
    }

    this.filteredUsers = tempUsers;
  }

  // --- Metodi per Form e Avatar ---

  registerUser() {
    this.avatarLoading = true;

    const newUser: User = {
      id: (this.users.length + 1).toString(),
      name: `${this.form.nome} ${this.form.cognome}`,
      signupDate: this.form.signupDateModal || new Date().toISOString().slice(0, 10),
      email: this.form.emailModal,
      status: this.form.isActive ? 'Attivo' : 'Inattivo',
      avatarUrl: this.form.avatar
    };

    // 3. INTEGR. INIZIALE DI FIREBASE: Qui andrebbe la logica per salvare l'utente
    /*
    this.firebaseService.addUser(newUser).then(() => {
        // Logica dopo il successo:
        this.avatarLoading = false;
        this.closeModal();
    }).catch(error => {
        // Gestione degli errori
        this.avatarLoading = false;
    });
    */

    // Manteniamo la logica di simulazione per il testing senza l'API attiva
    setTimeout(() => {
        this.users.push(newUser);
        this.applyFilters();
        this.avatarLoading = false;
        this.closeModal();
    }, 1500);
  }

  onAvatarChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.avatarLoading = true;
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.avatar = e.target?.result as string;
        this.avatarLoading = false;
      };
      reader.readAsDataURL(file);
      // Logica per caricare il file su Firebase Storage andrebbe qui
    }
  }

  triggerAvatarInput(avatarInput: HTMLInputElement) {
    avatarInput.click();
  }
}