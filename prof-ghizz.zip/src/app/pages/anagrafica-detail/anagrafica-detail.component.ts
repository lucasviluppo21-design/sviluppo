import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { PdfSchedaService } from '../../services/pdf-scheda-service';

// MODULAR AngularFire imports (no compat)
import { Firestore, doc, docData, updateDoc, deleteDoc } from '@angular/fire/firestore';
import { Storage, ref, uploadBytes, getDownloadURL } from '@angular/fire/storage';
import { AuthService } from '../../services/auth.service';

interface WorkoutCard {
  title: string;
  date: string;
  time?: string;
}

export interface User {
  id: string; // string per id Firestore
  name: string;
  email: string;
  signupDate: string;
  status: string;
  phone?: string;
  avatarUrl?: string;
  personalNotes?: string;
  birthDate?: string;
  gender?: string;
  address?: string;
  city?: string;
  cap?: string;
  cards?: WorkoutCard[];
}

@Component({
  selector: 'app-anagrafica-detail',
  templateUrl: './anagrafica-detail.component.html',
  styleUrls: ['./anagrafica-detail.component.css'],
  standalone: false
})
export class AnagraficaDetailComponent implements OnInit, OnDestroy {
  private firestore = inject(Firestore);
  private storage = inject(Storage);

  user?: User;
  showEditModal = false;
  showDeleteModal = false;
  editForm: Partial<User> = {};
  nome = '';
  cognome = '';

  userId: string = '';
  userSub?: Subscription;

  avatarLoading: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private pdfSchedaService: PdfSchedaService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.userId = this.route.snapshot.paramMap.get('id') || '';
    this.getUser();
  }

  ngOnDestroy(): void {
    this.userSub?.unsubscribe();
  }

  getUser() {
    const userDoc = doc(this.firestore, `users/${this.userId}`);
    this.userSub = docData(userDoc).subscribe(u => {
      if (!u) return;
      const asUser = u as User;
      if (Array.isArray(asUser.cards)) {
        asUser.cards = asUser.cards.sort((a, b) => {
          const aDate = this.parseItDateTime(a.date, a.time);
          const bDate = this.parseItDateTime(b.date, b.time);
          return (bDate?.getTime() || 0) - (aDate?.getTime() || 0);
        });
      }
      this.user = asUser;
    });
  }

  private parseItDateTime(d?: string, t?: string): Date | undefined {
    if (!d) return;
    const m = d.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!m) return;
    const dd = Number(m[1]);
    const mm = Number(m[2]) - 1;
    const yyyy = Number(m[3]);
    let hh = 0, min = 0, ss = 0;
    if (t) {
      const tm = t.match(/^(\d{2}):(\d{2})(?::(\d{2}))?$/);
      if (tm) {
        hh = Number(tm[1]);
        min = Number(tm[2]);
        ss = tm[3] ? Number(tm[3]) : 0;
      }
    }
    return new Date(yyyy, mm, dd, hh, min, ss);
  }

  private formatDateIT(iso?: string): string | null {
    if (!iso) return null;
    const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return null;
    return `${m[3]}/${m[2]}/${m[1]}`;
  }

  private normalizeTimeToHMS(time?: string): string {
    if (!time) return '';
    const m = time.match(/^(\d{2}):(\d{2})(?::(\d{2}))?$/);
    if (!m) return time;
    const ss = m[3] ?? '00';
    return `${m[1]}:${m[2]}:${ss}`;
  }

  async deleteCard(cardIndex: number) {
    if (!this.user) return;
    const cards = Array.isArray(this.user.cards) ? [...this.user.cards] : [];
    cards.splice(cardIndex, 1);

    const userDoc = doc(this.firestore, `users/${this.user.id}`);
    try {
      await this.authService.ensureSignedIn();
      await updateDoc(userDoc, { cards });
    } catch (err) {
      console.error('Error deleting card', err);
    }
    this.getUser();
  }

  openEditModal(): void {
    if (!this.user) return;
    this.editForm = {
      name: this.user.name,
      email: this.user.email,
      phone: this.user.phone,
      signupDate: this.user.signupDate,
      status: this.user.status,
      avatarUrl: this.user.avatarUrl,
      birthDate: this.user.birthDate,
      gender: this.user.gender,
      address: this.user.address,
      city: this.user.city,
      cap: this.user.cap,
      personalNotes: this.user.personalNotes
    };
    const parts = (this.user.name || '').trim().split(' ');
    this.nome = parts[0] || '';
    this.cognome = parts.slice(1).join(' ') || '';
    this.showEditModal = true;
  }

  closeEditModal(): void {
    this.showEditModal = false;
    this.editForm = {};
    this.nome = '';
    this.cognome = '';
  }

  async onAvatarChange(event: any): Promise<void> {
    const input = event.target as HTMLInputElement;
    if (!input.files || !input.files[0]) return;
    const file = input.files[0];
    this.avatarLoading = true;
    try {
      const filePath = `avatars/${Date.now()}_${file.name}`;
      const storageRef = ref(this.storage, filePath);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      this.editForm.avatarUrl = url;
    } finally {
      this.avatarLoading = false;
    }
  }

  triggerAvatarInput(input: HTMLInputElement): void {
    input.click();
  }

  async saveEditModal(): Promise<void> {
    if (!this.user) return;
    const fullName = `${this.nome || ''} ${this.cognome || ''}`.trim();
    if (!fullName || !this.editForm.email) {
      alert('Compila almeno Nome, Cognome ed Email.');
      return;
    }
    const updated: User = {
      ...this.user,
      name: fullName,
      email: this.editForm.email || '',
      phone: this.editForm.phone || '',
      birthDate: this.editForm.birthDate || '',
      gender: this.editForm.gender || '',
      address: this.editForm.address || '',
      city: this.editForm.city || '',
      cap: this.editForm.cap || '',
      personalNotes: this.editForm.personalNotes || '',
      avatarUrl: this.editForm.avatarUrl || this.user!.avatarUrl,
      signupDate: this.user!.signupDate,
      status: this.editForm.status || this.user!.status,
      cards: this.user!.cards || []
    };
    const userDoc = doc(this.firestore, `users/${this.user.id}`);
    try {
      await this.authService.ensureSignedIn();
      await updateDoc(userDoc, updated as any);
    } catch (err) {
      console.error('Error updating user', err);
    }
    this.user = updated;
    this.closeEditModal();
  }

  openDeleteModal(): void {
    this.showDeleteModal = true;
  }

  closeDeleteModal(): void {
    this.showDeleteModal = false;
  }

  async deleteUserCustom(): Promise<void> {
    if (!this.user) return;
    const userDoc = doc(this.firestore, `users/${this.user.id}`);
    try {
      await this.authService.ensureSignedIn();
      await deleteDoc(userDoc);
    } catch (err) {
      console.error('Error deleting user', err);
    }
    this.closeDeleteModal();
    this.router.navigate(['/anagrafica']);
  }
}