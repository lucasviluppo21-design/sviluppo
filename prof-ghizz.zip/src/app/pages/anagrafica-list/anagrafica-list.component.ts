import { Component, OnInit } from '@angular/core';
import { UserService, User } from '../../services/user.service';

@Component({
  selector: 'app-anagrafica-list',
  templateUrl: './anagrafica-list.component.html',
  styleUrls: ['./anagrafica-list.component.css'],
  standalone: false
})
export class AnagraficaListComponent implements OnInit {
  users: User[] = [];

  constructor(private userService: UserService) {}

  async ngOnInit() {
    // Se UserService.getAll() restituisce Promise<User[]>, usa await
    // In alternativa, se hai un getAll$(): Observable<User[]>, usa subscribe.
    this.users = await this.userService.getAll();
    // Esempio reattivo:
    // this.userService.getAll$().subscribe(users => this.users = users);
  }
}