import { Injectable } from '@angular/core';
// MODULAR AngularFire 
import {
  Firestore,
  collection,
  collectionData,
  query,
  where,
  doc,
  setDoc,
  getDocs,
} from '@angular/fire/firestore';
import { Observable, map, of } from 'rxjs';

export interface User {
  id: number;       // id numerico per compatibilità UI
  name: string;
  email: string;
  phone?: string;
}

@Injectable({ providedIn: 'root' })
export class UserService {
  constructor(private firestore: Firestore) {}

  // Ottieni tutti gli utenti da Firestore come Observable (reactive)
  getAll$(): Observable<User[]> {
    if (!this.firestore) {
      console.error('Firestore not available - getAll$');
      return of([] as User[]);
    }
    const usersCol = collection(this.firestore, 'users');
    return collectionData(usersCol, { idField: 'docId' }).pipe(
      map(list =>
        (list as any[]).map(d => ({
          id: d.numericId ?? 0,
          name: d.name,
          email: d.email,
          phone: d.phone
        }))
      )
    );
  }

  // Ottieni tutti gli utenti come Promise (unica volta)
  async getAll(): Promise<User[]> {
    if (!this.firestore) {
      console.error('Firestore not available - getAll');
      return [];
    }
    const usersCol = collection(this.firestore, 'users');
    const snap = await getDocs(usersCol);
    return snap.docs.map(docSnap => {
      const d = docSnap.data() as any;
      return {
        id: d.numericId ?? 0,
        name: d.name,
        email: d.email,
        phone: d.phone
      } as User;
    });
  }

  // Recupera utente per id numerico (cercando per campo 'numericId')
  getById$(id: number): Observable<User | undefined> {
    if (!this.firestore) {
      console.error('Firestore not available - getById$');
      return of(undefined);
    }
    const usersCol = collection(this.firestore, 'users');
    const q = query(usersCol, where('numericId', '==', id));
    return collectionData(q).pipe(
      map(list => {
        const d = list[0] as any;
        if (!d) return undefined;
        return {
          id: d.numericId ?? 0,
          name: d.name,
          email: d.email,
          phone: d.phone
        } as User;
      })
    );
  }

  // Versione Promise
  async getById(id: number): Promise<User | undefined> {
    if (!this.firestore) {
      console.error('Firestore not available - getById');
      return undefined;
    }
    const usersCol = collection(this.firestore, 'users');
    const q = query(usersCol, where('numericId', '==', id));
    const snap = await getDocs(q);
    const docSnap = snap.docs[0];
    if (!docSnap) return undefined;
    const d = docSnap.data() as any;
    return {
      id: d.numericId ?? 0,
      name: d.name,
      email: d.email,
      phone: d.phone
    } as User;
  }

  // Aggiunge un utente generando:
  // - docId (string) per Firestore
  // - numericId (number) per compatibilità con la UI
  async add(user: Omit<User, 'id'>): Promise<User> {
    // ATTENZIONE: usare un id string unico (per doc Firestore) e un id numerico (compatibilità UI)
    const docId = crypto.randomUUID();
    const numericId = Date.now();
    const payload = {
      numericId,
      name: user.name,
      email: user.email,
      phone: user.phone ?? ''
    };
    if (!this.firestore) {
      throw new Error('Firestore not available - add user');
    }
    await setDoc(doc(this.firestore, `users/${docId}`), payload);
    return { id: numericId, ...user };
  }
}